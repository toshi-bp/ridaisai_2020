block_breaking_small 説明


これはゲーム「block_breaking」の画面が大きすぎてプレイしにくい方に向けたゲームです。

「block_breaking_small.exe」というファイルを実行することでゲームを始めることができます。

詳しい説明は「block_breaking」のREADMEを参照してください。