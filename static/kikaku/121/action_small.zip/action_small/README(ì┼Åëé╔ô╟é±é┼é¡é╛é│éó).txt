action_small 説明


これはゲーム「action」の画面が大きすぎて、プレイしにくい方向けのゲームです。

詳しい説明は「action」のREADMEを参照してください。